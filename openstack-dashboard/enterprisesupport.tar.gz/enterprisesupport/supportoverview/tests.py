from horizon.test import helpers as test


class SupportoverviewTests(test.TestCase):
    # Unit tests for supportoverview.
    def test_me(self):
        self.assertTrue(1 + 1 == 2)
