from horizon import views

class supportlinksview(TemplateView):
    template_name = 'enterprisesupport/supportlinks/index.html'
