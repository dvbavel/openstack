from horizon.test import helpers as test


class SupportlinksTests(test.TestCase):
    # Unit tests for supportlinks.
    def test_me(self):
        self.assertTrue(1 + 1 == 2)
